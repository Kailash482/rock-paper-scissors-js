let userScore=0;
let computerScore=0;
const choices=document.querySelectorAll(".choice");
const msg=document.querySelector("#msg");
const userScorePara=document.querySelector("#user-score");
const compScorePara=document.querySelector("#computer-score");

const genCompChoice =() =>{
    const option=["paper","rock","scissor"]
    const randomIndex=Math.floor(Math.random()*3);
     return option[randomIndex]; 
}
const drawGame = () =>{
   
     msg.innerText="Game was Draw , Play Again";
     msg.style.backgroundColor="aqua";

};
    const showWinner = (userWin ,userChoice,compChoice) =>{
        if(userWin){
            userScore++;
            userScorePara.innerText=userScore;

            
            msg.innerText=`You win ! your ${userChoice}, beat ${compChoice}`;
            msg.style.backgroundColor="green";
        }
        else{
             computerScore++;
            compScorePara.innerText= computerScore;
           
             msg.innerText=`You lose !  ${userChoice}, beat  your ${compChoice}`
             msg.style.backgroundColor="red";
        }

    };


const playGame=(userChoice)=>{
    console.log("user choice=",userChoice);
    const compChoice=genCompChoice();
    console.log("comp choice =",compChoice);
    if(userChoice===compChoice){
        //Draw Game
        drawGame();
    }
    else{
        let userWin=true;
        if(userChoice==="rock"){
            // paper scissor
            userWin=compChoice==="paper" ? false : true;
        }
        else if(userChoice==="paper"){
             // rock scissor
            userWin=compChoice==="scissor" ? false :true;
        }
        else {
             // paper rock
             userWin=compChoice==="rock" ? false:true;

        }
        showWinner(userWin, userChoice,compChoice);
    }
};
choices.forEach((choice)=>{
    console.log(choice);
    choice.addEventListener("click", ()=>{
        const userChoice=choice.getAttribute("id");
       playGame(userChoice);
    })
})